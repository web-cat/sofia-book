/** Automatically generated file. DO NOT MODIFY */
package sofia.demo.breakout;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}