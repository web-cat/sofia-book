package sofia.demo.breakout;

import sofia.app.ShapeScreen;
import sofia.graphics.Color;
import sofia.graphics.LineShape;
import android.widget.TextView;

//-------------------------------------------------------------------------
/**
 * The main screen for the (incomplete) Breakout game.
 *
 * @author  Tony Allevato
 * @version 2013.03.05
 */
public class BreakoutScreen extends ShapeScreen
{
    //~ Constants .............................................................

    private static final Color[] BRICK_COLORS = {
        Color.red, Color.blue, Color.green, Color.yellow,
        Color.orange, Color.cyan, Color.magenta
    };

    //~ Fields ................................................................

    private float brickHeight;
    private TextView scoreLabel;
    private Ball ball;
    private int livesRemaining;
    private int score;


    //~ Public methods ........................................................

    // ----------------------------------------------------------
    /**
     * Initializes the shapes on the screen.
     */
    public void initialize()
    {
        setBackgroundColor(Color.black);

        brickHeight = getHeight() / 20;

        livesRemaining = 3;
        score = 0;

        for (int rows = 0; rows < 10; rows++)
        {
            for (int cols = 0; cols < 10; cols++)
            {
                float left = cols / 10f * getWidth();
                float top = rows * brickHeight;
                float right = (cols + 1) / 10f * getWidth() - 2;
                float bottom = (rows + 1) * brickHeight - 2;

                Brick brick = new Brick(left, top, right, bottom);
                brick.setColor(BRICK_COLORS[rows % BRICK_COLORS.length]);
                add(brick);
            }
        }

        ball = new Ball(getWidth() / 2, getHeight() - 10);

        addWall(0, 0, getWidth(), 0);
        addWall(0, 0, 0, getHeight());
        addWall(getWidth(), 0, getWidth(), getHeight());
        addWall(0, getHeight(), getWidth(), getHeight());

        add(ball);

        ball.restart();
    }


    //~ Private methods .......................................................

    // ----------------------------------------------------------
    /**
     * Add a "wall" to the screen; walls are really just invisible lines.
     *
     * @param left
     * @param top
     * @param right
     * @param bottom
     */
    private void addWall(float left, float top, float right, float bottom)
    {
        LineShape wall = new LineShape(left, top, right, bottom);
        add(wall);
    }
}
