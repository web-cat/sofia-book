package sofia.demo.breakout;

import sofia.graphics.RectangleShape;

//-------------------------------------------------------------------------
/**
 * A brick in the Breakout game.
 *
 * @author  Tony Allevato
 * @version 2013.03.05
 */
public class Brick extends RectangleShape
{
    //~ Constructors ..........................................................

    // ----------------------------------------------------------
    /**
     * Initializes a new brick with the specified coordinates.
     *
     * @param left
     * @param top
     * @param right
     * @param bottom
     */
    public Brick(float left, float top, float right, float bottom)
    {
        super(left, top, right, bottom);

        setFilled(true);
    }


    //~ Public methods ........................................................

    // ----------------------------------------------------------
    /**
     * This method is called by Sofia when a brick is involved in a collision
     * with a {@link Ball}.
     *
     * @param ball the ball that collided with the brick
     */
    public void onCollisionWith(Ball ball)
    {
        remove();
    }
}
