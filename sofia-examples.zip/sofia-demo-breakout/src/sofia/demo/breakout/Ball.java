package sofia.demo.breakout;

import sofia.graphics.Color;
import sofia.graphics.OvalShape;
import sofia.graphics.ShapeMotion;
import sofia.util.Random;

//-------------------------------------------------------------------------
/**
 * The ball in the Breakout game.
 *
 * @author  Tony Allevato
 * @version 2013.03.05
 */
public class Ball extends OvalShape
{
    //~ Constructors ..........................................................

    // ----------------------------------------------------------
    /**
     * Initializes a new ball at the specified position.
     *
     * @param x the x-coordinate of the center of the ball
     * @param y the y-coordinate of the center of the ball
     */
    public Ball(float x, float y)
    {
        super(x, y, 5);

        setShapeMotion(ShapeMotion.DYNAMIC);
        setRestitution(1.0f);

        setFilled(true);
        setColor(Color.lightGray);
    }


    //~ Public methods ........................................................

    // ----------------------------------------------------------
    /**
     * Restarts the ball's motion using a linear impulse to "push" it.
     */
    public void restart()
    {
        float vx = Random.generator().nextFloat(-50, 50);
        applyLinearImpulse(vx, -50);
    }
}
