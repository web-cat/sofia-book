package sofia.demo.tipcalc;

import sofia.app.Screen;
import sofia.app.ScreenLayout;
import android.annotation.SuppressLint;
import android.widget.EditText;

//-------------------------------------------------------------------------
/**
 * <p>
 * A screen that displays the main tip calculator GUI.
 * </p><p>
 * Since there is a layout file with a name matching this class in
 * res/layout/tipcalculatorscreen.xml (all lowercase because of Android naming
 * restrictions), that layout will be automatically loaded before the
 * initialize method is called.
 * </p><p>
 * The {@code scroll} attribute on the {@link ScreenLayout} annotation tells
 * Sofia that we want the layout to scroll if it doesn't fit on the screen.
 * This is useful if you have a form-like layout where the on-screen keyboard
 * might be visible and obscuring part of the display; using this annotation is
 * a bit easier than trying to wrap your layout in a {@code ScrollView} in the
 * WYSIWYG GUI editor.
 * </p>
 *
 * @author  Tony Allevato
 * @version 2013.03.04
 */
@ScreenLayout(scroll = true)
public class TipCalculatorScreen extends Screen
{
    //~ Fields ................................................................

    private EditText billAmount;
    private EditText tipAmount;
    private EditText billTotal;

    private TipModel tipModel;


    //~ Public methods ........................................................

    // ----------------------------------------------------------
    /**
     * Called when the tip calculator screen is created. By this point, the
     * {@code EditText} fields above will have already been pre-populated with
     * references to those widgets in the layout. We just need to do a little
     * bit of extra initialization to set up our data model.
     */
    public void initialize()
    {
        tipModel = new TipModel();
        tipModel.addObserver(this);

        // The 15% widget is selected by default in the layout, so we need to
        // enforce that default here; the button handlers below aren't called
        // unless the button is physically clicked.

        tipModel.setTipRate(0.15f);
    }


    // ----------------------------------------------------------
    /**
     * Called when the user has committed an editing operation in the widget
     * with ID "billAmount", by pressing the "Done" or "Enter" key on their
     * device's keyboard.
     */
    public void billAmountEditingDone()
    {
        float amount;

        try
        {
            amount = Float.parseFloat(billAmount.getText().toString());
        }
        catch (NumberFormatException e)
        {
            amount = 0.0f;
        }

        // Setting the bill amount causes the observers to be notified, so the
        // changeWasObserved method below will perform the actual updating of
        // the widgets.

        tipModel.setBillAmount(amount);
    }


    // ----------------------------------------------------------
    /**
     * Called when the 15% tip button is clicked.
     */
    public void tip15Clicked()
    {
        // Setting the tip rate causes the observers to be notified, so the
        // changeWasObserved method below will perform the actual updating of
        // the widgets.

        tipModel.setTipRate(0.15f);
    }


    // ----------------------------------------------------------
    /**
     * Called when the 18% tip button is clicked.
     */
    public void tip18Clicked()
    {
        tipModel.setTipRate(0.18f);
    }


    // ----------------------------------------------------------
    /**
     * Called when the 20% tip button is clicked.
     */
    public void tip20Clicked()
    {
        tipModel.setTipRate(0.20f);
    }


    // ----------------------------------------------------------
    /**
     * This method is called when a {@link TipModel} that this screen is
     * observing notifies its observers that a change has occurred. In our
     * case, this will happen when either the bill amount or the tip rate has
     * changed, so that we can update the rest of the widgets with the results.
     *
     * @param theTipModel the {@code TipModel} that was changed. In this simple
     *     example, this will always be the same object as the field
     *     {@code tipModel}, but an object that observes multiple instances of
     *     the same type can use this argument to differentiate them.
     */
    @SuppressLint("DefaultLocale")
    public void changeWasObserved(TipModel theTipModel)
    {
        String tipAmountString =
                String.format("%.2f", tipModel.getTipAmount());
        String billTotalString =
                String.format("%.2f", tipModel.getBillTotal());

        tipAmount.setText(tipAmountString);
        billTotal.setText(billTotalString);
    }
}
