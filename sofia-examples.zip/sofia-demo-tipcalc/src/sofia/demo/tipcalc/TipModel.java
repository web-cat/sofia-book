package sofia.demo.tipcalc;

//-------------------------------------------------------------------------
/**
 * <p>
 * This class represents the business logic for calculating the tip. Think of
 * it like a "machine" that takes two inputs (the amount of the bill
 * (pre-tip) and the tip rate), and provides two calculated outputs (the amount
 * of the tip alone, and the total amount of the bill with tip included).
 * </p><p>
 * This logic is factored out into a separate class so that we can make it
 * observable. The {@link sofia.util.Observable} class is like the same-named
 * class in {@code java.util}, but with a simpler API, and it uses reflection
 * to provide dynamic type-based dispatch of notification events instead of
 * statically-typed interfaces.
 * </p><p>
 * There are, of course, some things in here that aren't good design, like
 * using floats to store currency. But we'll just acknowledge that and move on
 * for the purposes of this example.
 * </p>
 *
 * @author  Tony Allevato
 * @version 2013.03.04
 */
public class TipModel extends sofia.util.Observable
{
    //~ Fields ................................................................

    private float billAmount;
    private float tipRate;


    //~ Public methods ........................................................

    // ----------------------------------------------------------
    /**
     * Gets the amount of the bill, before the tip (the subtotal).
     *
     * @return the amount of the bill, before the tip
     */
    public float getBillAmount()
    {
        return billAmount;
    }


    // ----------------------------------------------------------
    /**
     * Sets the amount of the bill, before the tip.
     *
     * @param newBillAmount the new amount of the bill before the tip
     */
    public void setBillAmount(float newBillAmount)
    {
        billAmount = newBillAmount;
        notifyObservers();
    }


    // ----------------------------------------------------------
    /**
     * Gets the tip rate, represented as a floating point value (for example,
     * a 15% tip would be 0.15).
     *
     * @return the tip rate
     */
    public float getTipRate()
    {
        return tipRate;
    }


    // ----------------------------------------------------------
    /**
     * Sets the tip rate, represented as a floating point value (for example,
     * a 15% tip would be 0.15).
     *
     * @param newTipRate the new tip rate
     */
    public void setTipRate(float newTipRate)
    {
        tipRate = newTipRate;
        notifyObservers();
    }


    // ----------------------------------------------------------
    /**
     * Gets the absolute amount of the tip by itself, calculated by multiplying
     * the bill subtotal and the tip rate.
     *
     * @return the absolute amount of the tip by itself
     */
    public float getTipAmount()
    {
        return billAmount * tipRate;
    }


    // ----------------------------------------------------------
    /**
     * Gets the total amount of the bill, including the tip.
     *
     * @return the total amount of the bill, including the tip
     */
    public float getBillTotal()
    {
        return billAmount + getTipAmount();
    }
}
