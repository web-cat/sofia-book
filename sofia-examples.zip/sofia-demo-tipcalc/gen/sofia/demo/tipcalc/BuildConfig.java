/** Automatically generated file. DO NOT MODIFY */
package sofia.demo.tipcalc;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}