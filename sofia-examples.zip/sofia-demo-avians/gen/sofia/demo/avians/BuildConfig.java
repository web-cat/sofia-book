/** Automatically generated file. DO NOT MODIFY */
package sofia.demo.avians;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}