/** Automatically generated file. DO NOT MODIFY */
package sofia.demo.mediadb;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}