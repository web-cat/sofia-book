package sofia.demo.mediadb;

import sofia.widget.ListView;
import sofia.widget.ProvidesSubtitle;
import sofia.widget.ProvidesTitle;

//-------------------------------------------------------------------------
/**
 * This class represents a single item in the media database. A media item has
 * a title and an author. Other fields could be added as well, such as media
 * type (book, CD, DVD...), runtime, and so forth.
 *
 * @author  Tony Allevato
 * @version 2013.03.02
 */
public class MediaItem
{
    //~ Fields ................................................................

    private String title;
    private String author;
    private boolean isNew;


    //~ Constructors ..........................................................

    // ----------------------------------------------------------
    /**
     * Initializes a newly created {@code MediaItem}.
     */
    public MediaItem()
    {
        isNew = true;
    }


    //~ Public methods ........................................................

    // ----------------------------------------------------------
    /**
     * <p>
     * Gets the title of the media item.
     * </p><p>
     * The {@link ProvidesTitle} annotation is used by Sofia's {@link ListView}
     * to indicate that the string returned by this method should be used to
     * display the title of the item in the list, rather than the default of
     * calling {@link #toString()} on the item.
     * </p>
     *
     * @return the title of the media item
     */
    @ProvidesTitle
    public String getTitle()
    {
        return title;
    }


    // ----------------------------------------------------------
    /**
     * Sets the title of the media item.
     *
     * @param newTitle the new title of the media item
     */
    public void setTitle(String newTitle)
    {
        title = newTitle;
    }


    // ----------------------------------------------------------
    /**
     * <p>
     * Gets the author of the media item.
     * </p><p>
     * The {@link ProvidesSubtitle} annotation is used by Sofia's
     * {@link ListView} to indicate that the string returned by this method
     * should be used to display the subtitle of the item in the list, which
     * will appear in small text underneath the item's title.
     * </p>
     *
     * @return the author of the media item
     */
    @ProvidesSubtitle
    public String getAuthor()
    {
        return author;
    }


    // ----------------------------------------------------------
    /**
     * Sets the author of the media item.
     *
     * @param newAuthor the new author of the media item
     */
    public void setAuthor(String newAuthor)
    {
        author = newAuthor;
    }


    // ----------------------------------------------------------
    /**
     * Returns true if the object is new (has not yet been added to the media
     * list) or false if it is stored in the list.
     *
     * @return true if the object is new (not yet added to the media list) or
     *     false if it is already stored
     */
    public boolean isNew()
    {
        return isNew;
    }


    // ----------------------------------------------------------
    /**
     * Clears the "new" flag on the media item to indicate that it has been
     * stored in the media list.
     */
    public void clearNew()
    {
        isNew = false;
    }
}
