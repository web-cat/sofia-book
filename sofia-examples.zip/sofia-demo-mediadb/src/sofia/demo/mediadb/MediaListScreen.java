package sofia.demo.mediadb;

import sofia.app.ListScreen;
import sofia.app.OptionsMenu;

//-------------------------------------------------------------------------
/**
 * <p>
 * The screen that displays the list of media items. Since we're extending
 * {@link ListScreen}, we don't need to provide our own layout -- this class
 * automatically provides a full-screen {@link ListView} for us.
 * </p><p>
 * The {@link OptionsMenu} annotation indicates that the same-named menu
 * resource should be loaded for the screen's action bar (or options menu on
 * older devices). Unlike layouts, menus are not auto-loaded -- the annotation
 * is required.
 * </p>
 *
 * @author  Tony Allevato
 * @version 2013.03.02
 */
@OptionsMenu
public class MediaListScreen extends ListScreen<MediaItem>
{
    //~ Public methods ........................................................

    // ----------------------------------------------------------
    /**
     * Called when the media list screen is created. Here we provide an
     * informative message to let the user know what to do when the list is
     * empty.
     */
    public void initialize()
    {
        setEmptyMessage(
                "Your media library is empty. Click the \"+\" "
                + "button above to create a new entry.");
    }


    // ----------------------------------------------------------
    /**
     * Called when the menu item with the ID "addItem" is clicked.
     */
    public void addItemClicked()
    {
        presentScreen(MediaItemScreen.class, new MediaItem());
    }


    // ----------------------------------------------------------
    /**
     * Called when an item in the list view is clicked.
     *
     * @param item the {@link MediaItem} that was clicked
     */
    public void listViewItemClicked(MediaItem item)
    {
        presentScreen(MediaItemScreen.class, item);
    }


    // ----------------------------------------------------------
    /**
     * Called when a presented {@link MediaItemScreen} finished successfully
     * (because it called the {@code finish} method and not canceled).
     *
     * @param item the {@code MediaItem}, updated by the presented screen
     */
    public void mediaItemScreenFinished(MediaItem item)
    {
        // If the item was new, we need to add it to the list view after it was
        // done being edited, and then clear the new flag so that future edits
        // don't re-add it.

        if (item.isNew())
        {
            add(item);
            item.clearNew();
        }
    }
}
