package sofia.demo.mediadb;

import android.widget.EditText;
import sofia.app.Screen;

//-------------------------------------------------------------------------
/**
 * <p>
 * A screen that displays a form to let the user edit a single media item in
 * the database.
 * </p><p>
 * Since there is a layout file with a name matching this class in
 * res/layout/mediaitemscreen.xml (all lowercase because of Android naming
 * restrictions), that layout will be automatically loaded before the
 * initialize method is called.
 * </p>
 *
 * @author  Tony Allevato
 * @version 2013.03.02
 */
public class MediaItemScreen extends Screen
{
    //~ Fields ................................................................

    // The media item being edited on this screen.
    private MediaItem item;

    // When the layout is loaded, the following fields are auto-populated with
    // references to the same named widgets in the layout. This happens before
    // the initialize method is called.
    private EditText itemTitle;
    private EditText itemAuthor;


    //~ Public methods ........................................................

    // ----------------------------------------------------------
    /**
     * Initializes the screen based on the values of attributes in the given
     * {@link MediaItem} object. Sofia knows to call this version of the
     * {@code initialize} method because the
     * {@link #presentScreen(Class, Object...)} call from
     * {@link MediaListScreen} passes a {@code MediaItem} object as the single
     * argument (after the screen class itself).
     *
     * @param theItem the {@code MediaItem} to edit on this screen
     */
    public void initialize(MediaItem theItem)
    {
        item = theItem;

        itemTitle.setText(item.getTitle());
        itemAuthor.setText(item.getAuthor());
    }


    // ----------------------------------------------------------
    /**
     * Called when the button with the ID "saveItem" is clicked. Here, we
     * update the item's attributes and then finish the activity.
     */
    public void saveItemClicked()
    {
        item.setTitle(itemTitle.getText().toString());
        item.setAuthor(itemAuthor.getText().toString());

        finish(item);
    }
}
